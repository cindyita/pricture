<div class="main">
    <div class="white-box d-flex justify-content-center align-items-center">
        <p>Sorry, We have not found what you are looking for. The link is invalid.</p>
    </div>
</div>


