<?php

define("BASEURL", "http://localhost/_prog/Projects/Pricture/");
define("BASEPATH", $_SERVER['DOCUMENT_ROOT']);
define("BASESELF", $_SERVER['PHP_SELF']);
define("DB_HOST", "192.145.239.40");
define("DB_NAME", "theblu48_pricture");
define("DB_USER", "theblu48_priadmin");
define("DB_PASS", "wBxNQH@LrHd$");
define("RECAPTCHA_SITE", "6LfXL-8oAAAAALy1VBHWDpAl744xZlrb6rCu5nbd");
define("RECAPTCHA_SECRET", "6LfXL-8oAAAAAIxJ0iLsH8Gvya6pH971tNH3c1vd");